#include <config.h>
#define GL_XMAP_INLINE _GL_EXTERN_INLINE
#include "gl_xmap.h"
