#include <config.h>
#define GL_MAP_INLINE _GL_EXTERN_INLINE
#include "gl_map.h"
